% Code to detect the lowest pixel value with skin color to get the bottom
% of the throat.

function [y] = getSkinPixel(I)
% I = temp(1).img;

% I2 = zeros(size(I, 1), size(I, 2));
for i = size(I,1):-1:1
    for j = 1:size(I,2)
        R = I(i,j,1);
        G = I(i,j,2);
        B = I(i,j,3);
        if(R > 95 && G > 40 && B > 20)
            v = [R,G,B];
            if((max(v) - min(v)) > 15)
                if(abs(R-G) > 15 && R > G && R > B)
                    % Skin color.
                    % I2(i, j) = 1;
                    % I(i, j, 2) = 128;
                    y = i;
                    return;
                end
            end
        end
    end
end

% imshow(I);

% Get the lowest row containing a skin colored pixel
% rows = all(I2 == 0, 2);
% for y = length(rows):-1:1
%     if rows(y) == 0
%         break;
%     end
% end

end