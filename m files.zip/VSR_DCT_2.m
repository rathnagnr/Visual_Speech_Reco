
% function [results, normFeat, dynFeat] = VSR_DCT_2(subject)
a = 1:34;
a = a(a ~= 21); a = a(a ~= 8);
% fprintf('Sub\t WRR\n');

% a = 1;

for subNo = a

sub = strcat('s', num2str(subNo));
% sub = 's9';

% Set the path where the variables extracted in Video_Preprocessing_2 are 
% stored. Also specify the path for the alignment files.
path = 'Variables/';
alignPath = strcat(path, sub, '_align/');

% Load the variable - the variable name which is loaded is allVids
load(strcat(path, sub, '.mat'));
N = length(allVids);
corrVidCount = 0;
filename = {allVids.filename};

% Trimming the videos to remove all the irrelevant frames (the frames in which the digit is not spoken).
% Structure to hold the trimmed videos
trimVid = struct();
i = 1;
for j = 1:N
    if ~isempty(allVids(j).vid)
        % Read the video files
        temp = allVids(j).vid;
        % Length of video
        noFr = length(temp);

        % Extract only those frames in which the digit is spoken
        fileID = fopen(strcat(alignPath, '/',...
            extractBefore(filename{j}, '.'), '.align'), 'r');
        text = textscan(fileID, '%d %d %s');
        text = [text{1}, text{2}];
        fclose(fileID);

        beginFr = floor(double(text(6, 1))/1000) - 1;
        endFr = ceil(double(text(6, 2))/1000);
        if beginFr > noFr
            fprintf('Video Corrupted! Sub: %s Vid: %s\n', sub, filename{j});
            corrVidCount = corrVidCount + 1;
            continue;
        end
        if endFr > noFr
            endFr = noFr;
        end
        
        % Get the useful frames
        trimVid(i).vid = temp(beginFr:endFr);
        % Get the video label also
        if strcmp(filename{j}(5), 'z')
            trimVid(i).label = 10;
        else
            trimVid(i).label = str2double(filename{j}(5));
        end
        i = i + 1;
    else
        corrVidCount = corrVidCount + 1;
    end
end
%%
% For normal DCT features: VecLen = 70; VecLen2 = 280
% For dynamic DCT features: VecLen = 50; VecLen2 = 280
% For dynamic LBP features: VecLen = NA; VecLen2 = 700

% fprintf('Vec\t WRR\n');
vecLen = 70; vecLen2 = 280;

% Choose among the following feature types: dct/dctdynamix/dct+throat/lbp/lbpdynamic/lbp+throat
feat1 = getFeatures_2(trimVid, 'dct', vecLen);

% feat2 = getFeatures_2(trimVid, 'dynamic', vecLen2);

N = length(trimVid);

% Get the DCT of the features
for i = 1:N
    temp = dct2(feat1(i).feat);
    
    temp = temp(:);
    if length(temp) >= vecLen2
        feat1(i).dct = temp(1:vecLen2); %/norm(temp(1:vecLen));  % Uncomment the last part to normalize the histogram feature vector
    else
        q = vecLen2 - length(temp);
        feat1(i).dct = padarray(temp, [q, 0], 'post');
    end
    % Set the label
    feat1(i).label = trimVid(i).label;
end
clear temp;

%
% Divide the data into training and test sets
rng('default');

% Set model parameters
template = templateSVM('Standardize', 1, 'KernelFunction', 'linear',...
    'BoxConstraint', 3, 'KernelScale', 'auto');
options = statset('UseParallel', 1);

iter = 1;
results = zeros(iter, 1);

for i = 1:iter
    d = randperm(N);
    s = floor(0.7*N);
    xInd = d(1:s);
    yInd = d(s+1:end);

    %---- Normal Features
    % x = features(xInd);
    x = reshape(extractfield(feat1(xInd), 'dct'), [vecLen2, s]);
    xLbl = extractfield(feat1(xInd), 'label');
    % y = features(yInd);
    y = reshape(extractfield(feat1(yInd), 'dct'), [vecLen2, N-s]);
    yLbl = extractfield(feat1(yInd), 'label');
    
    % Train the model
    Mdl = fitcecoc(x, xLbl, 'Learners', template, 'Options', options,...
        'Coding', 'onevsone', 'ObservationsIn', 'columns');
    % Record the results
    res = predict(Mdl, y');
    results(i) = 100*(length(find(res == yLbl'))/length(res));
%     figure;
%     plotconfusion(ind2vec(yLbl), ind2vec(res'), 'Normal');
end

mean(results)

end

%end