% Function called in main to get LBP features extracted from the dataset
% mentioned in argument.

function features = getFeatures_2(videoIn, type, len)
% videoIn = trimVid;
n = length(videoIn);
% type = 'normal';

features = struct();
% len = 50;
% len2 = 50;
% nBins = 64;

if strcmp(type, 'dct')
%% Simple DCT Features
% fprintf('DCT Vec Len: %d\n', len);
for i = 1:n
    for k = 1:length(videoIn(i).vid)
        temp1 = zigzag(dct2(single(videoIn(i).vid(k).mouth)));
        features(i).feat(:, k) = temp1(2:len+1)/norm(temp1(2:len+1));
    end
end

elseif strcmp(type, 'lbp')
%% Simple LBP Features
nBins = len;
for i = 1:n
    for k = 1:length(videoIn(i).vid)
        temp1 = single(videoIn(i).vid(k).mouth);
        temp1 = lbp(temp1, 2, 8, 0, 'i');
        features(i).feat(:, k) = histcounts(temp1(:), nBins,...
            'Normalization', 'probability');
    end
end

%% DCT Features for each frame - 5 frames for dynamic feature extraction
elseif strcmp(type, 'dctdynamic')
sideFr = 2; % Number of neighboring frames used to calculate the diffImg
seq = -sideFr:sideFr;
seq = seq(find(seq ~= 0)); %#ok<FNDSB>
lenseq = length(seq) + 1;
% len = 50;

for i = 1:n
    % Load the structure into a 3D array and copy the first and last frames
    % twice
    noFr = length(videoIn(i).vid);
    temp = zeros(size(videoIn(i).vid(1).mouth, 1),...
        size(videoIn(i).vid(1).mouth, 2), noFr);
    for k = 1:noFr
        temp(:, :, k) = single(videoIn(i).vid(k).mouth);
    end
    
    for k = 1:noFr
        diffImg = zeros(size(temp, 1), size(temp, 2), lenseq);
        diffImg(:, :, sideFr+1) = temp(:, :, k);
        % Get the difference images
        for t = seq
            if(((k+t) < 1) || ((k+t) > size(temp, 3)))
                diffImg(:,:, t+sideFr+1) = zeros(size(temp, 1),...
                    size(temp, 2));
            else
                diffImg(:,:, t+sideFr+1) = -1*sign(t)*temp(:,:,k)+ ...
                    sign(t)*temp(:, :, k+t);
                
                % Equalize the historam of each difference image to get
                % more information
%                 [diffImg(:,:,t+sideFr+1), ~] = histeq(diffImg(:,:,t+sideFr+1));
            end
        end
        
        % Compute the DCT of the difference images and add to the feature
        dctImg = zeros(len, lenseq);
        for t = 1:lenseq
            tempDCT = zigzag(dct2(diffImg(:, :, t)));
%             if norm(tempDCT(2:len+1)) == 0
%                 dctImg(:, t) = zeros(len, 1);
%             else
%                 dctImg(:, t) = tempDCT(2:len+1)/norm(tempDCT(2:len+1));
%             end
            dctImg(:, t) = tempDCT(1:len);
        end
        features(i).feat(:, k) = dctImg(:)/norm(dctImg(:));
    end
end

%% Dynamic LBP Features
elseif strcmp(type, 'lbpdynamic')
%% Dynamic LBP Features
% sideFr = 4;
for i = 1:n
    noFr = length(videoIn(i).vid);
    temp = zeros(size(videoIn(i).vid(1).mouth, 1),...
        size(videoIn(i).vid(1).mouth, 2), noFr);
    for k = 1:noFr
        temp(:, :, k) = single(videoIn(i).vid(k).mouth);
    end

    for k = 1:noFr
        diffImg = zeros(nBins, 5);
        temp1 = temp(:, :, k);
        temp1 = lbp(temp1, 2, 8, 0, 'i');
        diffImg(:, 3) = histcounts(temp1(:), nBins,...
            'Normalization', 'probability');
        % Get the difference images
        for t = [-2, -1, 1, 2]
            if (((k+t) < 1) || ((k+t) > noFr))
                diffImg(:, t+3) = zeros(nBins, 1);
            else
                temp2 = temp(:, :, k+t);
                temp2 = lbp(temp2, 2, 8, 0, 'i');
                temp2 = histcounts(temp2(:), nBins,...
                    'Normalization', 'probability');
                diffImg(:, t+2+1) = -1*sign(t)*diffImg(:, 3) +...
                    sign(t)*temp2';
            end
        end

        features(i).feat(:, k) = diffImg(:)/norm(diffImg(:));
    end
end

%% Simple DCT features with throat
elseif strcmp(type, 'dct+throat')
for i = 1:n
    for k = 1:length(videoIn(i).vid)
        if ~isempty(videoIn(i).vid(k).throat)
            temp1 = single(videoIn(i).vid(k).mouth);
            temp2 = single(videoIn(i).vid(k).throat);
            temp = [temp1; temp2];
        else
            temp = single(videoIn(i).vid(k).mouth);
        end
        temp = zigzag(dct2(temp));
        features(i).feat(:, k) = temp(2:len+1)/norm(temp(2:len+1));
    end
end

%% Simple LBP features with throat
elseif strcmp(type, 'lbp+throat')
for i = 1:n
    for k = 1:length(videoIn(i).vid)
        if ~isempty(videoIn(i).vid(k).throat)
            temp1 = single(videoIn(i).vid(k).mouth);
            temp2 = single(videoIn(i).vid(k).throat);
            temp = [temp1; temp2];
        else
            temp = single(videoIn(i).vid(k).mouth);
        end
        
        temp = lbp(temp, 2, 8, 0, 'i');
        features(i).feat(:, k) = histcounts(temp(:), nBins,...
            'Normalization', 'probability');
    end
end

%%
else
    fprintf('Choose a correct type!\n');
end

%% DCT Features for each frame - 5 frames for dynamic feature extraction;
% The DCT for the original frame is discarded in this snippet - gives poorer performance

% len = 240;
% for i = 1:n
%     temp = videoIn(i).frames;
%     for k = 1:size(temp, 3)
%         diffImg = zeros(size(temp, 1), size(temp, 2), 4);
%         % diffImg(:, :, 3) = temp(:, :, k);
%         % Get the four difference images
%         j = 1;
%         for t = [-2, -1, 1, 2]
%             if(((k+t) < 1) || ((k+t) > size(temp, 3)))
%                 diffImg(:, :, j) = zeros(size(temp, 1), size(temp, 2));
%             else
%                 diffImg(:, :, j) = -1*sign(t)*temp(:, :, k) + ...
%                                       sign(t)*temp(:, :, k+t);
%             end
%             j = j + 1;
%         end
%         
%         % Compute the DCT of the difference images and add to the feature
%         dctImg = zeros(len/4, 4);
%         for t = 1:4
%             tempDCT = zigzag(dct2(diffImg(:, :, t)));
%             dctImg(:, t) = tempDCT(2:len/4+1);
%         end
%         features(i).feat(:, k) = reshape(dctImg, [len, 1]);
%     end
% end

end