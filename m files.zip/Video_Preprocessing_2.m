% Video to crop mouth region by detecting the mouth in each frame. Helps to
% remove the small movements of the mouth in the cropped videos earlier.

% This code detects the throat too and crops it.

function [] = Video_Preprocessing_2(sub)

% sub = 's2';

% Change the path to where the dataset is stored
path = 'Dataset\';

files = dir(strcat(path, sub, '\*.mpg'));
files = extractfield(files, 'name');

% Create the face detector object
faceDetector = vision.CascadeObjectDetector('ClassificationModel',...
    'FrontalFaceCART', 'MinSize', [110 110], 'MaxSize', [180 180]);

% Create the mouth detector object
mouthDetector = vision.CascadeObjectDetector('Mouth',...
    'MergeThreshold', 4, 'UseROI', 1);

% Specify the mouth width and height
mW = 60;
mH = 36;

% Structure for storing the cropped mouth and neck region. THe structure
% has two main fields: vid - which has two more fields (one for mouth and
% one for throat); and filename - this is to obtain the corresponding align
% file and the label.
allVids = struct();

% Create progress bar
f = waitbar(0, strcat('Processing Videos:', ' ', sub));

% Read the video files - each video file has 74 frames.
% The mouth is detected from each frame and cropped to a fixed size.
for i = 1:length(files)
    
    filename = strcat(path, sub, '\', files{i});
    v = VideoReader(filename); %#ok<TNMLP>
    
    % Convert the video into a 3D matrix - this is for easy traversal
    % between frames of the video
    vid = struct();
    j = 1;
    while hasFrame(v)
        vid(j).img = readFrame(v);
        j = j + 1;
    end
    
    % Detect the face
    noFr = length(vid);
    facebb = [];
    j = 1;
    while numel(facebb) == 0
        facebb = faceDetector(vid(j).img);
        j = j + 1;
        if j > noFr
            break;
        end
    end
    
    % If no face is detected, then exit the loop and proceed with the next
    % video
    if numel(facebb) == 0
        fprintf('Face not found! Vid: %s\n', files{i});
        continue;
    end
    % Detect the mouth using the lower half of the facebb as roi
    facebb(2) = facebb(2) + floor(facebb(4)/2);
    facebb(4) = floor(facebb(4)/2);
    mouthbb = [];
    j = 1;
    while numel(mouthbb) == 0
        mouthbb = step(mouthDetector, vid(j).img, facebb);
        
        % If multiple mouths are detected, then take the one with the
        % lowest y coordinate
        if size(mouthbb, 2) > 1
            [~, ind] = max(mouthbb(:, 2));
            mouthbb = mouthbb(ind, :);
        end
        
        j = j + 1;
        if j > noFr
            break;
        end
    end
    
    % If no mouth is detected in any frame, then exit the loop and proceed
    % with next video
    if numel(mouthbb) == 0
        fprintf('Mouth not found! Vid: %s\n', files{i});
        continue;
    end
    
    % Crop the frames -- by tracking feature points in the mouth region
    
    % Detect feature points in the face region.
    points = detectMinEigenFeatures(rgb2gray(vid(1).img),...
        'ROI', mouthbb, 'MinQuality', 0.01);
    % initCent = mean(points.Location);
    % points = points.selectStrongest(2);

    % Display the detected points.
%     figure; imshow(temp(1).img), hold on, title('Detected features');
%     plot(points); plot(cent(1), cent(2), '*');

    if isempty(points)
        fprintf('No feature pts detected! Vid: %s\n', files{i});
    else
        % Create a point tracker
        pointTracker = vision.PointTracker('MaxBidirectionalError', 2);
        % Initialize tracker with the initial point locations and initial
        % video frame.
        points = points.Location;
        initialize(pointTracker, points, vid(1).img);
        % Make a copy of the points to be used for computing the geometric
        % transformation between the points in the previous and the current
        % frames
        oldPoints = points;
        % Convert the bbox to coordinates
        % bboxPoints = bbox2points(mouthbb);
        count = 0;
        flag = 0;

        for j = 1:noFr
            % Track the points. Note that some points may be lost.
            [points, isFound] = step(pointTracker, vid(j).img);
            visPoints = points(isFound, :);
            oldInliers = oldPoints(isFound, :);

            if size(visPoints, 1) >= 2 % need at least 2 points
                % Estimate the geometric transformation between the old points
                % and the new points and eliminate outliers
                [~, ~, visPoints] = estimateGeometricTransform(...
                    oldInliers, visPoints, 'similarity', 'MaxDistance', 4);

                % Reset the points
                oldPoints = visPoints;
                setPoints(pointTracker, oldPoints);
                % Create a bbox of size mW by mH, with the centroid at cent
                % If number of visible points drops by half, do NOT
                % calculate the new centroid coordinates.
                if length(find(isFound))/length(isFound) > 0.5
                    cent = mean(visPoints);
                end
                
%                 imshow(imcrop(img, bbox), 'InitialMagnification', 200);
%                 pause(0.025);
            else
                flag = 1;
                count = count + 1;
            end
            bbox = zeros(1, 4);
            bbox(1) = cent(1) - mW/2 - 1;
            bbox(2) = cent(2) - mH/2 - 1;
            bbox(3) = mW; bbox(4) = mH;
            % Check if the bounding box is exceeding the video frame size
            if bbox(2) + bbox(4) > size(vid(j).img, 1)
                bbox(2) = size(vid(j).img, 1) - bbox(4);
            end
            
            allVids(i).vid(j).mouth = rgb2gray(imcrop(vid(j).img, bbox));
            
            % Create a bounding box for the throat
            bboxTh = zeros(1, 4);
            bboxTh(1) = bbox(1);
            bboxTh(2) = bbox(2) + bbox(4);
            bboxTh(3) = mW;
            bboxTh(4) = floor(getSkinPixel(vid(j).img) - bboxTh(2));
            % img = insertShape(temp(j).img, 'Rectangle', bboxTh,...
            %     'Color', {'green'});
            
            % Check if the throat is going beyond the frame itself. If yes,
            % then keep the throat part empty
            if bboxTh(2) < 288
                allVids(i).vid(j).throat = rgb2gray(imcrop(vid(j).img,...
                    bboxTh));
            else
                allVids(i).vid(j).throat = [];
            end

        end
        allVids(i).filename = files{i};

        if flag == 1
            fprintf('Tracking Points not found in %d frames! Vid: %s\n',...
                count, files{i});
            count = 0; %#ok<*NASGU>
            flag = 0;
        end
        
    end
    
    waitbar(i/length(files), f);
    
end

% Save the variable with mouth and throat parts cropped into a folder called 'Variable'
fprintf('Saving the variable...\n');
saveVarPath = '.\Variables\';
save(strcat(saveVarPath, sub, '.mat'), 'allVids');

close(f);
end
